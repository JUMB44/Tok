const VIDEO_EXTENSIONS = new Set([".mp4", ".webm", ".ogg", ".ogv"]);

function getPathExtension(pathname) {
  const match = pathname.toLowerCase().match(/\.[a-z0-9]+$/);
  return match ? match[0] : "";
}

function asUrl(rawUrl) {
  const value = String(rawUrl || "").trim();
  if (!value) throw new Error("Paste a video link first.");

  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid link beginning with https://.");
  }

  if (!["https:", "http:"].includes(url.protocol)) {
    throw new Error("Only HTTP and HTTPS links are supported.");
  }
  return url;
}

function youtubeSource(url) {
  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  let id = null;

  if (host === "youtu.be") {
    id = url.pathname.split("/").filter(Boolean)[0] || null;
  } else if (host === "youtube.com" || host.endsWith(".youtube.com")) {
    if (url.pathname === "/watch") id = url.searchParams.get("v");
    else {
      const parts = url.pathname.split("/").filter(Boolean);
      if (["embed", "shorts", "live"].includes(parts[0])) id = parts[1] || null;
    }
  }

  if (!id || !/^[\w-]{11}$/.test(id)) return null;

  const embed = new URL(`https://www.youtube-nocookie.com/embed/${id}`);
  embed.searchParams.set("autoplay", "1");
  // Start muted so browsers that block audible autoplay can still start the video.
  embed.searchParams.set("mute", "1");
  embed.searchParams.set("enablejsapi", "1");
  embed.searchParams.set("origin", window.location.origin);
  embed.searchParams.set("controls", "1");
  embed.searchParams.set("playsinline", "1");
  embed.searchParams.set("rel", "0");
  return { kind: "embed", provider: "YouTube", src: embed.toString(), audioControl: true };
}

function vimeoSource(url) {
  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  if (host !== "vimeo.com" && host !== "player.vimeo.com") return null;

  const parts = url.pathname.split("/").filter(Boolean);
  const id = host === "player.vimeo.com" ? parts[1] : parts[0];
  if (!id || !/^\d+$/.test(id)) return null;

  const embed = new URL(`https://player.vimeo.com/video/${id}`);
  embed.searchParams.set("autoplay", "1");
  embed.searchParams.set("muted", "1");
  embed.searchParams.set("autopause", "0");
  embed.searchParams.set("api", "1");
  embed.searchParams.set("title", "0");
  embed.searchParams.set("byline", "0");
  embed.searchParams.set("portrait", "0");
  return { kind: "embed", provider: "Vimeo", src: embed.toString(), audioControl: true };
}

function googleDriveSource(url) {
  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  if (host !== "drive.google.com") return null;

  const match = url.pathname.match(/\/file\/d\/([^/]+)/);
  const id = match?.[1] || url.searchParams.get("id");
  if (!id) return null;

  const embed = new URL(`https://drive.google.com/file/d/${encodeURIComponent(id)}/preview`);
  embed.searchParams.set("autoplay", "1");
  return { kind: "embed", provider: "Google Drive", src: embed.toString(), audioControl: false };
}

function normalizeDropbox(url) {
  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  if (host !== "dropbox.com" && host !== "dl.dropboxusercontent.com") return url;
  if (host === "dropbox.com") {
    url.searchParams.delete("dl");
    url.searchParams.set("raw", "1");
  }
  return url;
}

function withAutoplayParams(url) {
  const result = new URL(url.toString());
  result.searchParams.set("autoplay", "1");
  result.searchParams.set("muted", "1");
  result.searchParams.set("mute", "1");
  return result;
}

/**
 * sourceMode: "auto" | "file" | "embed".
 * Generic embed URLs must be provider embed/player URLs, not ordinary watch pages.
 */
export function getVideoSource(rawUrl, sourceMode = "auto") {
  const url = asUrl(rawUrl);
  const youtube = youtubeSource(url);
  if (youtube) return youtube;
  const vimeo = vimeoSource(url);
  if (vimeo) return vimeo;
  const drive = googleDriveSource(url);
  if (drive) return drive;

  const normalizedUrl = normalizeDropbox(url);
  const mode = ["auto", "file", "embed"].includes(sourceMode) ? sourceMode : "auto";
  const extension = getPathExtension(normalizedUrl.pathname);
  const isDirectFile = VIDEO_EXTENSIONS.has(extension) || normalizedUrl.searchParams.get("raw") === "1";

  if (mode === "file" || (mode === "auto" && isDirectFile)) {
    return {
      kind: "file",
      provider: "Direct video file",
      src: normalizedUrl.toString(),
      audioControl: true,
    };
  }

  if (mode === "embed" || mode === "auto") {
    const host = normalizedUrl.hostname.toLowerCase().replace(/^www\./, "");
    const src = withAutoplayParams(normalizedUrl);
    return {
      kind: "embed",
      provider: host || "External player",
      src: src.toString(),
      audioControl: false,
    };
  }

  throw new Error("Unsupported video source.");
}
