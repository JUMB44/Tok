import OBR from "@owlbear-rodeo/sdk";
import { getVideoSource } from "./video-utils.js";

const MODAL_ID = "com.example.token-intro/cinematic";
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(window.location.search);
let intro = {};
let activeVideo = null;
let activeFrame = null;
let activeProvider = null;
let autoCloseTimer = null;

function showError(message) {
  $("loadingState").classList.add("hidden");
  $("videoError").textContent = message;
  $("videoError").classList.remove("hidden");
}

function showSoundButton(label = "Enable sound") {
  $("soundButton").classList.remove("hidden");
  $("soundButton").textContent = label;
}

function sendEmbedAudioCommands() {
  if (!activeFrame?.contentWindow) return;
  try {
    if (activeProvider === "YouTube") {
      activeFrame.contentWindow.postMessage(JSON.stringify({ event: "command", func: "unMute", args: [] }), "*");
      activeFrame.contentWindow.postMessage(JSON.stringify({ event: "command", func: "playVideo", args: [] }), "*");
    } else if (activeProvider === "Vimeo") {
      activeFrame.contentWindow.postMessage(JSON.stringify({ method: "setVolume", value: 1 }), "*");
      activeFrame.contentWindow.postMessage(JSON.stringify({ method: "play" }), "*");
    }
  } catch (error) {
    console.warn("Could not send audio command to embedded video:", error);
  }
}

async function closeScene() {
  if (autoCloseTimer) window.clearTimeout(autoCloseTimer);
  try { await OBR.modal.close(MODAL_ID); }
  catch (error) { console.error("Could not close video modal:", error); }
}

async function startDirectVideo(video) {
  video.autoplay = true;
  video.muted = false;
  video.defaultMuted = false;
  video.setAttribute("autoplay", "");
  try {
    await video.play();
    $("loadingState").classList.add("hidden");
    $("soundHint").textContent = "Playing with sound";
    showSoundButton("Mute");
    return;
  } catch (audibleError) {
    console.info("Audible autoplay was blocked; retrying with muted autoplay.", audibleError);
  }

  video.muted = true;
  video.defaultMuted = true;
  video.setAttribute("muted", "");
  try {
    await video.play();
    $("loadingState").classList.add("hidden");
    $("soundHint").textContent = "Video is playing automatically. Sound may require one tap.";
    showSoundButton("Enable sound");
  } catch (mutedError) {
    console.info("Muted autoplay was also blocked.", mutedError);
    $("loadingDetail").textContent = "This browser blocked automatic playback. Select the button to start the video.";
    const start = document.createElement("button");
    start.className = "start-button";
    start.type = "button";
    start.textContent = "Start video";
    start.addEventListener("click", async () => {
      try {
        video.muted = false;
        video.defaultMuted = false;
        video.removeAttribute("muted");
        await video.play();
        $("loadingState").classList.add("hidden");
        $("soundHint").textContent = "Playing with sound";
        showSoundButton("Mute");
      } catch (error) {
        console.error("Could not start video:", error);
        showError("Playback could not start. Check the video link and the browser's media settings.");
      }
    }, { once: true });
    $("loadingState").append(start);
  }
}

try {
  const raw = params.get("intro");
  if (!raw) throw new Error("No video data was received.");
  intro = JSON.parse(raw);
  if (!intro.videoUrl) throw new Error("The video link is missing.");
} catch (error) {
  showError(error?.message || "The video data is invalid.");
}

if (intro.videoUrl) {
  try {
    const source = getVideoSource(intro.videoUrl, intro.sourceMode || "auto");
    const mount = $("mediaMount");

    if (source.kind === "embed") {
      const frame = document.createElement("iframe");
      frame.src = source.src;
      frame.title = `${source.provider} video player`;
      frame.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
      frame.allowFullscreen = true;
      frame.referrerPolicy = "strict-origin-when-cross-origin";
      frame.addEventListener("load", () => {
        $("loadingState").classList.add("hidden");
      }, { once: true });
      mount.append(frame);
      activeFrame = frame;
      activeProvider = source.provider;
      $("loadingDetail").textContent = `Connecting to ${source.provider}…`;
      if (source.audioControl) {
        $("soundHint").textContent = "Video starts automatically. Sound may require one tap.";
        showSoundButton("Enable sound");
      } else {
        $("soundHint").textContent = "Video starts automatically when supported by the embedded player.";
      }
    } else {
      const video = document.createElement("video");
      video.src = source.src;
      video.autoplay = true;
      video.muted = false;
      video.defaultMuted = false;
      video.playsInline = true;
      video.controls = true;
      video.preload = "auto";
      video.setAttribute("autoplay", "");
      video.setAttribute("playsinline", "");
      video.setAttribute("webkit-playsinline", "");
      video.addEventListener("loadeddata", () => $("loadingState").classList.add("hidden"), { once: true });
      video.addEventListener("ended", () => {
        if (!Number(intro.duration)) closeScene();
      });
      video.addEventListener("error", () => {
        showError("This video could not be played. Use a public direct MP4, WebM, or OGG link.");
      }, { once: true });
      mount.append(video);
      activeVideo = video;
      await startDirectVideo(video);
    }

    const duration = Math.max(0, Math.min(3600, Number(intro.duration) || 0));
    if (duration > 0) autoCloseTimer = window.setTimeout(closeScene, duration * 1000);
  } catch (error) {
    showError(error?.message || "The video link is invalid.");
  }
}

$("soundButton").addEventListener("click", async () => {
  if (activeVideo) {
    if (activeVideo.muted) {
      try {
        activeVideo.muted = false;
        activeVideo.defaultMuted = false;
        activeVideo.removeAttribute("muted");
        await activeVideo.play();
        $("soundButton").textContent = "Mute";
        $("soundHint").textContent = "Sound is on.";
      } catch (error) {
        activeVideo.muted = true;
        console.warn("Could not enable sound:", error);
        $("soundHint").textContent = "Sound could not be enabled. Use the video player's audio controls.";
      }
    } else {
      activeVideo.muted = true;
      $("soundButton").textContent = "Enable sound";
      $("soundHint").textContent = "Sound is off.";
    }
    return;
  }

  if (activeFrame && (activeProvider === "YouTube" || activeProvider === "Vimeo")) {
    sendEmbedAudioCommands();
    $("soundHint").textContent = `Sent the sound command to ${activeProvider}. If needed, use the player's audio control.`;
    $("soundButton").textContent = "Try sound again";
  }
});

$("closeCinema").addEventListener("click", closeScene);
