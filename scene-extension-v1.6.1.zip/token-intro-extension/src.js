import OBR from "@owlbear-rodeo/sdk";
import "./style.css";
import { getVideoSource } from "./video-utils.js";

const EXT = "com.example.token-intro";
const CHANNEL = `${EXT}.play`;
const MODAL_ID = `${EXT}/cinematic`;
let role = "PLAYER";
let currentConfig = { videoUrl: "", sourceMode: "auto", duration: 0 };

const root = document.querySelector("#app");
root.innerHTML = `
  <main class="shell">
    <header class="topbar">
      <div class="brand-mark" aria-hidden="true"><span></span></div>
      <div class="brand-copy">
        <h1>Scene</h1>
        <p>Room-wide video playback</p>
      </div>
      <span id="role" class="role">CONNECTING</span>
    </header>

    <section id="gmPanel" class="panel hidden">
      <div class="section-heading">
        <div>
          <h2>Video source</h2>
          <p>Paste a public video link. Playback starts automatically for connected players.</p>
        </div>
      </div>

      <label for="videoUrl">Video link</label>
      <input id="videoUrl" type="url" inputmode="url" placeholder="https://…" autocomplete="url" spellcheck="false" />

      <div class="source-row">
        <div class="source-field">
          <label for="sourceMode">Link type</label>
          <select id="sourceMode">
            <option value="auto">Auto detect</option>
            <option value="file">Direct video file</option>
            <option value="embed">Embedded player link</option>
          </select>
        </div>
        <p class="hint source-help">Use a public MP4, WebM, or OGG file link, or a provider's embed/player link.</p>
      </div>

      <div class="preview-heading"><span>Preview</span><span id="providerLabel">No video loaded</span></div>
      <div class="video-preview" id="videoPreview">
        <div class="preview-placeholder">
          <div class="preview-icon">▶</div>
          <b>Video preview</b>
          <small>Paste a link, then select Preview</small>
        </div>
      </div>
      <button id="preview" class="button button-secondary preview-button" type="button">Preview video</button>

      <div class="duration-row">
        <label for="duration">Auto-close after</label>
        <div class="number-wrap"><input id="duration" type="number" min="0" max="3600" value="0" /><span>sec</span></div>
      </div>
      <p class="hint">Set to 0 to keep the video open until it ends or you stop it.</p>

      <div class="button-row">
        <button id="save" class="button button-secondary" type="button">Save</button>
        <button id="play" class="button button-primary" type="button"><span aria-hidden="true">▶</span> Play for everyone</button>
      </div>
      <button id="stop" class="button button-stop" type="button">Stop for everyone</button>
      <div id="status" class="status" role="status" aria-live="polite">Paste a public video link to get started.</div>
      <div class="footer-note">Local files must be hosted online first. Room players need a link they can access.</div>
    </section>

    <section id="playerPanel" class="panel hidden">
      <div class="player-ready">
        <div class="ready-icon"><span></span></div>
        <p class="eyebrow">READY</p>
        <h2>Waiting for the Game Master</h2>
        <p class="ready-copy">The video will open automatically when the Game Master starts playback.</p>
      </div>
    </section>
  </main>
`;

document.querySelector("#boot")?.remove();
const $ = (id) => document.getElementById(id);

function setStatus(message, isError = false) {
  const status = $("status");
  status.textContent = message;
  status.classList.toggle("error", isError);
}

function getEditorConfig() {
  const duration = Math.max(0, Math.min(3600, Number.parseInt($("duration").value || "0", 10) || 0));
  return {
    videoUrl: $("videoUrl").value.trim(),
    sourceMode: $("sourceMode").value,
    duration,
  };
}

function clearPreview() {
  $("videoPreview").innerHTML = `
    <div class="preview-placeholder">
      <div class="preview-icon">▶</div>
      <b>Video preview</b>
      <small>Paste a link, then select Preview</small>
    </div>`;
  $("providerLabel").textContent = "No video loaded";
}

function applyConfig(config = {}) {
  currentConfig = {
    videoUrl: String(config.videoUrl || ""),
    sourceMode: ["auto", "file", "embed"].includes(config.sourceMode) ? config.sourceMode : "auto",
    duration: Math.max(0, Math.min(3600, Number(config.duration) || 0)),
  };
  $("videoUrl").value = currentConfig.videoUrl;
  $("sourceMode").value = currentConfig.sourceMode;
  $("duration").value = String(currentConfig.duration);
  clearPreview();
  if (currentConfig.videoUrl) {
    try {
      const source = getVideoSource(currentConfig.videoUrl, currentConfig.sourceMode);
      $("providerLabel").textContent = source.provider;
    } catch {
      // Keep the editor usable if an old scene contains an invalid URL.
    }
  }
}

async function loadConfig() {
  const metadata = await OBR.scene.getMetadata();
  const extensionData = metadata?.[EXT] || {};

  if (extensionData.video && typeof extensionData.video === "object") {
    applyConfig(extensionData.video);
    return;
  }

  const previousEntries = Object.values(extensionData.scripts || {});
  const previous = previousEntries.find((entry) => entry?.videoUrl);
  if (previous) {
    applyConfig(previous);
    await persistConfig(currentConfig);
    setStatus("Previous saved video settings were imported.");
  }
}

async function persistConfig(config) {
  const metadata = await OBR.scene.getMetadata();
  await OBR.scene.setMetadata({
    [EXT]: {
      ...(metadata?.[EXT] || {}),
      video: config,
    },
  });
  currentConfig = { ...config };
}

async function openLocalVideo(intro) {
  const url = new URL("/cinema.html", window.location.origin);
  url.searchParams.set("intro", JSON.stringify(intro));
  try { await OBR.modal.close(MODAL_ID); } catch { /* No previous video is open. */ }
  await OBR.modal.open({
    id: MODAL_ID,
    url: url.toString(),
    fullScreen: true,
    hideBackdrop: false,
    hidePaper: true,
  });
}

async function closeLocalVideo() {
  try { await OBR.modal.close(MODAL_ID); } catch { /* No video is open. */ }
}

function previewVideo() {
  let source;
  try {
    const config = getEditorConfig();
    source = getVideoSource(config.videoUrl, config.sourceMode);
  } catch (error) {
    setStatus(error.message, true);
    return;
  }

  const container = $("videoPreview");
  container.innerHTML = "";
  $("providerLabel").textContent = source.provider;

  if (source.kind === "embed") {
    const frame = document.createElement("iframe");
    const previewUrl = new URL(source.src);
    previewUrl.searchParams.set("autoplay", "0");
    previewUrl.searchParams.set("mute", "1");
    previewUrl.searchParams.set("muted", "1");
    frame.src = previewUrl.toString();
    frame.title = `${source.provider} preview`;
    frame.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen";
    frame.allowFullscreen = true;
    frame.referrerPolicy = "strict-origin-when-cross-origin";
    container.append(frame);
  } else {
    const video = document.createElement("video");
    video.src = source.src;
    video.controls = true;
    video.muted = true;
    video.playsInline = true;
    video.preload = "metadata";
    video.addEventListener("error", () => setStatus("Preview could not be loaded. Check that the link is public and points directly to a video file.", true), { once: true });
    container.append(video);
  }
  setStatus(`Preview loaded · ${source.provider}`);
}

$("preview").addEventListener("click", previewVideo);

$("save").addEventListener("click", async () => {
  const config = getEditorConfig();
  try {
    getVideoSource(config.videoUrl, config.sourceMode);
    await persistConfig(config);
    setStatus("Video settings saved to this scene.");
  } catch (error) {
    setStatus(error.message || "Could not save video settings.", true);
  }
});

$("play").addEventListener("click", async () => {
  const config = getEditorConfig();
  let source;
  try {
    source = getVideoSource(config.videoUrl, config.sourceMode);
  } catch (error) {
    setStatus(error.message, true);
    return;
  }

  const intro = {
    type: "PLAY_INTRO_VIDEO",
    videoUrl: config.videoUrl,
    sourceMode: config.sourceMode,
    videoKind: source.kind,
    provider: source.provider,
    duration: config.duration,
    sentAt: Date.now(),
  };

  try {
    await persistConfig(config);
    await openLocalVideo(intro);
    if (!OBR.broadcast || typeof OBR.broadcast.sendMessage !== "function") {
      throw new Error("Broadcast API is unavailable. Check the Owlbear SDK installation.");
    }
    await OBR.broadcast.sendMessage(CHANNEL, intro, { destination: "REMOTE" });
    setStatus("Playback started locally and sent to connected players.");
  } catch (error) {
    console.error("Scene playback failed:", error);
    setStatus(`Could not start playback: ${error?.message || "Check the console for details."}`, true);
  }
});

$("stop").addEventListener("click", async () => {
  try {
    await OBR.broadcast.sendMessage(CHANNEL, { type: "STOP_INTRO_VIDEO", sentAt: Date.now() }, { destination: "REMOTE" });
    await closeLocalVideo();
    setStatus("Stop command sent to everyone.");
  } catch (error) {
    console.error("Scene stop failed:", error);
    setStatus("Could not stop playback for everyone.", true);
  }
});

OBR.onReady(async () => {
  try {
    role = await OBR.player.getRole();
    $("role").textContent = role === "GM" ? "GAME MASTER" : "PLAYER";
    if (role === "GM") {
      $("gmPanel").classList.remove("hidden");
      await loadConfig();
    } else {
      $("playerPanel").classList.remove("hidden");
    }
  } catch (error) {
    console.error("Scene initialization failed:", error);
    $("role").textContent = "OFFLINE";
    if (role === "GM") $("gmPanel").classList.remove("hidden");
    else $("playerPanel").classList.remove("hidden");
  }
});
