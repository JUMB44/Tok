import OBR from "@owlbear-rodeo/sdk";
import { getVideoSource } from "./video-utils.js";

const CHANNEL = "com.example.token-intro.play";
const MODAL_ID = "com.example.token-intro/cinematic";

OBR.onReady(() => {
  OBR.broadcast.onMessage(CHANNEL, async (event) => {
    const message = event.data;
    if (!message || typeof message !== "object") return;

    try {
      if (message.type === "PLAY_INTRO_VIDEO") {
        const source = getVideoSource(message.videoUrl, message.sourceMode || "auto");
        const intro = {
          type: "PLAY_INTRO_VIDEO",
          videoUrl: String(message.videoUrl),
          sourceMode: ["auto", "file", "embed"].includes(message.sourceMode) ? message.sourceMode : "auto",
          videoKind: source.kind,
          provider: source.provider,
          duration: Math.max(0, Math.min(3600, Number(message.duration) || 0)),
          sentAt: Number(message.sentAt) || Date.now(),
        };
        const url = new URL("/cinema.html", window.location.origin);
        url.searchParams.set("intro", JSON.stringify(intro));

        try { await OBR.modal.close(MODAL_ID); } catch { /* No previous video is open. */ }
        await OBR.modal.open({
          id: MODAL_ID,
          url: url.toString(),
          fullScreen: true,
          hideBackdrop: false,
          hidePaper: true,
        });
      }

      if (message.type === "STOP_INTRO_VIDEO") {
        await OBR.modal.close(MODAL_ID);
      }
    } catch (error) {
      console.error("Scene background error:", error);
      try {
        await OBR.notification.show(`Scene: ${error?.message || "Could not open the video."}`, "ERROR");
      } catch { /* Notification API may be unavailable. */ }
    }
  });
});
